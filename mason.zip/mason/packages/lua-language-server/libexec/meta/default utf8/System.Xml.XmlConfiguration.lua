---@meta

---@source System.Xml.dll
---@class System.Xml.XmlConfiguration.XmlReaderSection: System.Configuration.ConfigurationSection
---@source System.Xml.dll
---@field CollapseWhiteSpaceIntoEmptyStringString string
---@source System.Xml.dll
---@field ProhibitDefaultResolverString string
---@source System.Xml.dll
CS.System.Xml.XmlConfiguration.XmlReaderSection = {}


---@source System.Xml.dll
---@class System.Xml.XmlConfiguration.XsltConfigSection: System.Configuration.ConfigurationSection
---@source System.Xml.dll
---@field ProhibitDefaultResolverString string
---@source System.Xml.dll
CS.System.Xml.XmlConfiguration.XsltConfigSection = {}
