text

```lua
local foo = "bar"
```
